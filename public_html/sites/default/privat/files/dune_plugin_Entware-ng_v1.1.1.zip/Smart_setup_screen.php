<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/abstract_controls_screen.php';

///////////////////////////////////////////////////////////////////////////

class SmartSetupScreen extends AbstractControlsScreen
{
    const ID = 'setup';
	private $platform = null;
	private $install_dir = null;
	private $counter = 0;
    ///////////////////////////////////////////////////////////////////////

    public function __construct()
    {
        parent::__construct(self::ID);
    }

    public function do_get_control_defs(&$plugin_cookies)
    {
        $defs = array();
		
        $main_icon = isset($plugin_cookies->main_icon) ?  $plugin_cookies->main_icon : 'yes';
        $show_ops = array();
        $show_ops['yes'] = '%tr%t1';
        $show_ops['no'] = '%tr%t2';
		$cpuARM = shell_exec("cat /proc/cpuinfo | grep 'ARMv7' | tail -n1 | awk '{print $1}'");
		if ($cpuARM == true)
			$this->platform = 'ARMv7';
		else
			$this->platform = 'mipsel';
		$q = HD::ver();
		$this->add_button($defs,
			'whats_new', 
			"%ext%<key_local>d__1<p>$q</p></key_local>",
			'%tr%t50', 500
		);
		if (file_exists('/opt/bin/opkg')){
			if (file_exists('/opt/bin/mc')){
				$this->add_button($defs,
				'uninstall_mc', 'Midnight Commander (file manager)',
				'%tr%t17', 500
				);
			}else{
				$this->add_button($defs,
				'install_mc', 'Midnight Commander (file manager)',
				'%tr%t4', 500
				);
			}
			
			if (file_exists('/opt/bin/transmission-daemon')){
				
				$this->add_button($defs,
				'setup_transmission', 'Transmission (BitTorrent client)',
				'%tr%t23', 500
				);
				
			}else{
				$this->add_button($defs,
				'install_transmission', 'Transmission (BitTorrent client)',
				'%tr%t4', 500
				);
			}
			if ($this->platform=='ARMv7'){
				if (file_exists('/opt/bin/deluge')){
					$this->add_button($defs,
					'setup_deluge', 'Deluge (BitTorrent client)',
					'%tr%t23', 500
					);
				}else{
					$this->add_button($defs,
					'install_deluge', 'Deluge (BitTorrent client)',
					'%tr%t4', 500
					);
				}
			}
			if (file_exists('/opt/bin/aria2c')){
				$this->add_button($defs,
				'uninstall_aria2c', 'Aria2c (download utility)',
				'%tr%t17', 500
				);
			}else{
				$this->add_button($defs,
				'install_aria2c', 'Aria2c (download utility)',
				'%tr%t4', 500
				);
			}
			ControlFactory::add_label($defs, "__________________________________________", '______________________');
			$this->add_button($defs,
			'uninstall_entware', 'Entware-ng',
			'%tr%t17', 500
			);

		}else{
			
			$this->add_button($defs,
			'install_dialog', 'Entware-ng',
            '%tr%t4', 500
			);
			ControlFactory::add_label($defs, "This is software repository for network attached storages,", '');
			ControlFactory::add_label($defs, "routers and other embedded devices.", '');
			ControlFactory::add_label($defs, "https://github.com/Entware-ng/Entware-ng", '');
		}
		
		ControlFactory::add_label($defs, "__________________________________________", '______________________');
		$this->add_combobox($defs,
            'main_icon', '%tr%t3',
            $main_icon, $show_ops, 500, true
		);
		$this->add_button($defs,
			'reboot', '',
			'%tr%t39', 500
			);
        return $defs;
    }

    public function get_control_defs(MediaURL $media_url, &$plugin_cookies)
    {
        return $this->do_get_control_defs($plugin_cookies);
    }

    public function handle_user_input(&$user_input, &$plugin_cookies)
    {
        $attrs['dialog_params'] = array('frame_style' => DIALOG_FRAME_STYLE_GLASS);
		if ($user_input->control_id == 'whats_new')
        {
			$defs = array();
			$doc = file_get_contents('http://dune-club.info/plugins/update/'.DuneSystem::$properties['plugin_name'].'/info.txt');
			ControlFactory::add_multiline_label($defs, '', $doc, 10);
			ControlFactory::add_close_dialog_button($defs, 'ОК', 300);
			return ActionFactory::show_dialog('%tr%t51', $defs, true, 1100,$attrs);
        }
		if ($user_input->control_id === 'main_icon')
            $plugin_cookies->main_icon = $user_input->main_icon;
		if ($user_input->control_id === 'show_log'){
			$this->counter = $this->counter +1;
			$qtime = HD::sec_format_duration($this->counter);
			ControlFactory::add_label($defs, '', "%ext%<key_local>sec__1<p>$qtime</p></key_local>");
			$d_complete = array_reverse(file(DuneSystem::$properties['tmp_dir_path']. '/logs'));
			$data = str_replace(array("\033[m","\033[1;32m","\033[1;31m","\033[1;37m","\033[33m","\033[39m","\033[32m","\033[1m","\033[22m","\033[36m"), '',implode("",$d_complete));
			ControlFactory::add_multiline_label($defs, '', $data, 10);
			if (preg_match("|Сompleted|",file_get_contents (DuneSystem::$properties['tmp_dir_path']. '/logs'))){
				if (isset ($user_input->transmission_dir)){
					$q = file_get_contents(DuneSystem::$properties['install_dir_path'].'/bin/settings.json');
					$q = str_replace("/transmission/downloads", $user_input->transmission_dir . "/transmission", $q);
					$q = str_replace("/transmission/watch", $user_input->transmission_dir . "/transmission/watch", $q);
					file_put_contents('/opt/etc/transmission/settings.json', $q);
					echo $user_input->transmission_dir . "/transmission/watch";
					if (!file_exists($user_input->transmission_dir . "/transmission"))
						mkdir($user_input->transmission_dir . "/transmission", 0777);
					if (!file_exists($user_input->transmission_dir . "/transmission/watch"))
						mkdir($user_input->transmission_dir . "/transmission/watch", 0777);
				}
				if (isset ($user_input->deluge_dir)){
					$q = file_get_contents(DuneSystem::$properties['install_dir_path'].'/bin/core.conf');
					$q = str_replace("/D/Downloads", $user_input->deluge_dir . "/Downloads", $q);
					file_put_contents('/opt/etc/deluge/core.conf', $q);
					if (!file_exists($user_input->deluge_dir . "/Downloads"))
						mkdir($user_input->deluge_dir . "/Downloads", 0777);
				}
				$install_dialog = ActionFactory::reset_controls($this->do_get_control_defs($plugin_cookies));
			}else{
				if (isset ($user_input->transmission_dir))
					$add_params['transmission_dir'] = $user_input->transmission_dir;
				else if (isset ($user_input->deluge_dir))
					$add_params['deluge_dir'] = $user_input->deluge_dir;
				else
					$add_params=null;
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'show_log',$add_params);
			}
			
			$attrs['timer'] = ActionFactory::timer(1000);
			$attrs['actions'] = array(GUI_EVENT_TIMER => ActionFactory::close_dialog_and_run($install_dialog));
			return  ActionFactory::show_dialog('%tr%t19',$defs,false, 1000,$attrs);
		}
		if ($user_input->control_id === 'uninstall_mc'){
			$add_params['del_dialog'] = 'uninstall_mc1';
			return UserInputHandlerRegistry::create_action($this, 'uninstall_dialog', $add_params);
		}
		if ($user_input->control_id === 'uninstall_mc1'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/uninstall_mc.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'install_mc'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/install_mc.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'install_deluge'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/install_deluge.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$defs = array();
			$install_dir = 0;
			$install_ops = array();
			$install_ops[0] = '%tr%t8';
			foreach (glob('/tmp/mnt/storage/*') as $file){
				if (is_dir($file)){
					if (preg_match("|ext3|", exec("mount | grep \"$file\""))){
						$install_ops[$file] = substr($file,17,strlen($file)) . ' (' . HD::get_storage_size($file) .')';
						if (file_exists($file .'/Downloads'))
							$install_dir = $file;
					}
				}
			}		
			ControlFactory::add_multiline_label($defs, '', '%tr%t21', 8);
			ControlFactory::add_combobox($defs, $this, null,
				'deluge_dir', '',
				$install_dir, $install_ops, 900, false, false
			);
			ControlFactory::add_vgap($defs, 30);
			$this->counter = 0;
			$install_dialog = UserInputHandlerRegistry::create_action($this, 'show_log',$add_params=null);
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t6', 200, $install_dialog);
			return  ActionFactory::show_dialog('%tr%t41',$defs, true,1000,$attrs);
		}
		if ($user_input->control_id === 'install_aria2c'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/install_aria2c.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'uninstall_transmission'){
			$add_params['del_dialog'] = 'uninstall_transmission1';
			return UserInputHandlerRegistry::create_action($this, 'uninstall_dialog', $add_params);
		}
		if ($user_input->control_id === 'uninstall_transmission1'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/uninstall_transmission.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'uninstall_deluge'){
			$add_params['del_dialog'] = 'uninstall_deluge1';
			return UserInputHandlerRegistry::create_action($this, 'uninstall_dialog', $add_params);
		}
		if ($user_input->control_id === 'uninstall_deluge1'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/uninstall_deluge.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'uninstall_aria2c'){
			$add_params['del_dialog'] = 'uninstall_aria2c1';
			return UserInputHandlerRegistry::create_action($this, 'uninstall_dialog', $add_params);
		}
		if ($user_input->control_id === 'uninstall_aria2c1'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/uninstall_aria2c.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'do_reboot'){
			exec('reboot > /dev/null &');
		}
		if ($user_input->control_id === 'reboot'){
			$defs = array();
			ControlFactory::add_multiline_label($defs, '', '%tr%t40', 8);
			$reboot = UserInputHandlerRegistry::create_action($this, 'do_reboot');
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_reboot', '%tr%t1', 250, $reboot);
			ControlFactory::add_close_dialog_button($defs, '%tr%t2', 250);
			return  ActionFactory::show_dialog('%tr%t39',$defs, true,1000,$attrs);
		}
		if ($user_input->control_id === 'install_transmission'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/install_transmission.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$defs = array();
			$install_dir = 0;
			$install_ops = array();
			$install_ops[0] = '%tr%t8';
			foreach (glob('/tmp/mnt/storage/*') as $file){
				if (is_dir($file)){
					if (preg_match("|ext3|", exec("mount | grep \"$file\""))){
						$install_ops[$file] = substr($file,17,strlen($file)) . ' (' . HD::get_storage_size($file) .')';
						if (file_exists($file .'/transmission'))
							$install_dir = $file;
					}
				}
			}		
			ControlFactory::add_multiline_label($defs, '', '%tr%t21', 8);
			ControlFactory::add_combobox($defs, $this, null,
				'transmission_dir', '',
				$install_dir, $install_ops, 900, false, false
			);
			ControlFactory::add_vgap($defs, 30);
			$install_dialog = UserInputHandlerRegistry::create_action($this, 'show_log',$add_params=null);
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t6', 200, $install_dialog);
			return  ActionFactory::show_dialog('%tr%t22',$defs, true,1000,$attrs);
		}
		if ($user_input->control_id === 'setup_deluge'){
			$defs = array();
			ControlFactory::add_label($defs, "", '%tr%t31');
			ControlFactory::add_label($defs, "", 'http://'.HD::get_ip_address().':888');
			ControlFactory::add_label($defs, "", '%tr%t32');
			if (shell_exec ('pidof deluged') == true){
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'stop_deluge');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t34', 800, $install_dialog);
			}else{
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'start_deluge');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t33', 800, $install_dialog);
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'start_deluge_daemon');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t42', 800, $install_dialog);
			}
			$da = file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh');
			if (preg_match("|#/opt/etc/init.d/S80deluged|",$da)){
				if (preg_match("|#deluge-start|",$da)){
					$install_dialog = UserInputHandlerRegistry::create_action($this, 'autostart_deluge_on');
					ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t35', 800, $install_dialog);
				}else{
					$install_dialog = UserInputHandlerRegistry::create_action($this, 'autostart_deluge_off');
					ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t36', 800, $install_dialog);
				}
			}
			if (preg_match("|#deluge-start|",$da)){
				if (preg_match("|#/opt/etc/init.d/S80deluged|",$da)){
					$install_dialog = UserInputHandlerRegistry::create_action($this, 'autostart_deluged_on');
					ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t43', 800, $install_dialog);
				}else{
					$install_dialog = UserInputHandlerRegistry::create_action($this, 'autostart_deluged_off');
					ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t44', 800, $install_dialog);
				}
			}
			if (file_exists('/opt/etc/deluge/auth')){
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'deluged_login');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t45', 800, $install_dialog);
			}
						
			$install_dialog = UserInputHandlerRegistry::create_action($this, 'uninstall_deluge');
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t17', 800, $install_dialog);
			return  ActionFactory::show_dialog('%tr%t23',$defs, true,0,$attrs);
		}
		if ($user_input->control_id == 'deluged_login')
        {
			$defs = array();
			$login_settings = array();
			$l=file('/opt/etc/deluge/auth');
			if (isset($l[1])){
				$tmp = explode (':',$l[1]);
				$login_settings['user_login'] = $tmp[0];
				$login_settings['user_pass'] = $tmp[1];
			}				
			$user_login = isset($login_settings['user_login']) ? $login_settings['user_login'] : 'deluge';
			$user_pass = isset($login_settings['user_pass']) ? $login_settings['user_pass'] : 'deluge';
			ControlFactory::add_multiline_label($defs,'' ,'%tr%t48',6);
			ControlFactory::add_text_field($defs, $this, $add_params=null,
                    'user_login',
                    '',
                    $user_login, 0, 0, 0, 1, 750, 0, false
            );
			ControlFactory::add_text_field($defs, $this, $add_params=null,
                    'user_pass',
                    '',
                    $user_pass, 0, 0, 0, 1, 750, 0, false
            );
			$add_params['deluge_auth'] = trim($l[0]);
			$do_new_login_action = UserInputHandlerRegistry::create_action($this, 'do_login_action',$add_params);
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'apply_subscription', 'Применить', 350, $do_new_login_action);
			return ActionFactory::show_dialog("%tr%t45", $defs, true,1000,$attrs);
        }
		if ($user_input->control_id === 'do_login_action')
        {
			$q = $user_input->deluge_auth."\n".$user_input->user_login.":".$user_input->user_pass;
			file_put_contents('/opt/etc/deluge/auth', $q);
			return ActionFactory::show_title_dialog('%tr%t49', null, '', 1000, 1);
		}
		if ($user_input->control_id === 'setup_transmission'){
			$defs = array();
			ControlFactory::add_label($defs, "", '%tr%t30');
			ControlFactory::add_label($defs, "", 'http://'.HD::get_ip_address().':9091');
			if (shell_exec ('pidof transmission-daemon') == true){
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'stop_transmission');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t29', 700, $install_dialog);
			}else{
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'start_transmission');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t28', 700, $install_dialog);
			}
			if (preg_match("|#transmission-start|",file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh'))){
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'autostart_transmission_on');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t24', 700, $install_dialog);
			}else{
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'autostart_transmission_off');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t25', 700, $install_dialog);
			}
			
			$install_dialog = UserInputHandlerRegistry::create_action($this, 'uninstall_transmission');
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t17', 700, $install_dialog);
			return  ActionFactory::show_dialog('%tr%t23',$defs, true,0,$attrs);
		}
		if ($user_input->control_id === 'uninstall_dialog'){
			$defs = array();
			ControlFactory::add_label($defs, '', '%tr%t53');
			if (isset ($user_input->del_dialog)){
				$do = UserInputHandlerRegistry::create_action($this, $user_input->del_dialog);
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_do', '%tr%t1', 250, $do);
			}
			ControlFactory::add_close_dialog_button($defs, '%tr%t2', 250);
			return  ActionFactory::show_dialog('%tr%t52',$defs, true,1000,$attrs);
		}
		if ($user_input->control_id === 'uninstall_entware'){
			$add_params['del_dialog'] = 'uninstall_entware1';
			return UserInputHandlerRegistry::create_action($this, 'uninstall_dialog', $add_params);
		}
		if ($user_input->control_id === 'uninstall_entware1'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/uninstall.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'start_transmission'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/start_transmission.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'stop_transmission'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/stop_transmission.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'start_deluge'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/start_deluge.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'start_deluge_daemon'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/start_deluged.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'stop_deluge'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/stop_deluge.sh >'.DuneSystem::$properties['tmp_dir_path']. '/logs &');
			$this->counter = 0;
			return UserInputHandlerRegistry::create_action($this, 'show_log');
		}
		if ($user_input->control_id === 'autostart_transmission_on'){
			$q = file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh');
			$q = str_replace('#transmission-start', 'transmission-start', $q);
			file_put_contents(DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh', $q);
			return ActionFactory::show_title_dialog('%tr%t26', null, '', 1000, 1);
		}
		if ($user_input->control_id === 'autostart_transmission_off'){
			$q = file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh');
			$q = str_replace('transmission-start', '#transmission-start', $q);
			file_put_contents(DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh', $q);
			return ActionFactory::show_title_dialog('%tr%t27', null, '', 1000, 1);
		}
		if ($user_input->control_id === 'autostart_deluge_on'){
			$q = file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh');
			$q = str_replace('#deluge-start', 'deluge-start', $q);
			file_put_contents(DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh', $q);
			return ActionFactory::show_title_dialog('%tr%t37', null, '', 1000, 1);
		}
		if ($user_input->control_id === 'autostart_deluge_off'){
			$q = file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh');
			$q = str_replace('deluge-start', '#deluge-start', $q);
			file_put_contents(DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh', $q);
			return ActionFactory::show_title_dialog('%tr%t38', null, '', 1000, 1);
		}
		if ($user_input->control_id === 'autostart_deluged_on'){
			$q = file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh');
			$q = str_replace('#/opt/etc/init.d/S80deluged', '/opt/etc/init.d/S80deluged', $q);
			file_put_contents(DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh', $q);
			return ActionFactory::show_title_dialog('%tr%t37', null, '', 1000, 1);
		}
		if ($user_input->control_id === 'autostart_deluged_off'){
			$q = file_get_contents (DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh');
			$q = str_replace('/opt/etc/init.d/S80deluged', '#/opt/etc/init.d/S80deluged', $q);
			file_put_contents(DuneSystem::$properties['install_dir_path'].'/bin/boot_end.sh', $q);
			return ActionFactory::show_title_dialog('%tr%t38', null, '', 1000, 1);
		}
		if ($user_input->control_id === 'install_dialog'){
			$defs = array();
			$install_dir = $this->counter = 0;
			$install_ops = array();
			$install_ops[0] = '%tr%t8';
			if (file_exists('/persistfs')){
				$install_ops['/persistfs'] = '%tr%t7';
				if (file_exists('/persistfs/Entware-ng'))
					$install_dir = '/persistfs';
			}
			foreach (glob('/tmp/mnt/storage/*') as $file){
				if (is_dir($file)){
					if (preg_match("|ext3|", exec("mount | grep \"$file\""))){
						$install_ops[$file] = substr($file,17,strlen($file)) . ' (' . HD::get_storage_size($file) .')';
						if (file_exists($file .'/Entware-ng'))
							$install_dir = $file;
					}
				}
			}		
			ControlFactory::add_multiline_label($defs, '', '%tr%t9', 8);
			ControlFactory::add_combobox($defs, $this, null,
				'install_dir', '',
				$install_dir, $install_ops, 900, $need_confirm = false, $need_apply = false
			);
			ControlFactory::add_vgap($defs, 30);
			$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog2');
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t6', 200, $install_dialog);
			return  ActionFactory::show_dialog('%tr%t5',$defs, true,1000,$attrs);
		}
		if ($user_input->control_id === 'install_dialog2'){
			if ($user_input->install_dir == '0')
				return ActionFactory::show_title_dialog('%tr%t10', null, $user_input->install_dir, 1000, 1);
			$this->install_dir = $user_input->install_dir;
			if (file_exists($user_input->install_dir . '/Entware-ng'))
				shell_exec ('rm -rf '. $user_input->install_dir . '/Entware-ng');
			$q = shell_exec ('mkdir -p '. $user_input->install_dir . '/Entware-ng');
			if (file_exists($user_input->install_dir . '/Entware-ng')){
				if (file_exists('/opt'))
					shell_exec ('rm -rf /opt');
				shell_exec ('ln -sf '. $user_input->install_dir . '/Entware-ng /opt');
				$defs = array();
				ControlFactory::add_label($defs, "", '%tr%t11');
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog3');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t6', 200, $install_dialog);
				return  ActionFactory::show_dialog('%tr%t12',$defs, false,0,$attrs);
			}else
				return ActionFactory::show_title_dialog('%tr%t10', null, $q, 1000, 1);
		}
		
		if ($user_input->control_id === 'install_dialog3'){
			exec(DuneSystem::$properties['install_dir_path'].'/bin/'.$this->platform.".sh >> /tmp/entware_install.log &");
			shell_exec('[ -z "`pidof telnetd`" ] && telnetd');
			shell_exec('[ ! -f /config/telnetd ] && touch /config/telnetd');
			shell_exec('echo "Info: Telnet ON" >> /tmp/entware_install.log');
			return UserInputHandlerRegistry::create_action($this, 'install_dialog4');
		}
		
		if ($user_input->control_id === 'install_dialog4'){
			$defs = array();
			$this->counter = $this->counter +1;
			$qtime = HD::sec_format_duration($this->counter);
			ControlFactory::add_label($defs, '', "%ext%<key_local>sec__1<p>$qtime</p></key_local>");
			if (file_exists("/tmp/entware_install.log"))
				$d_complete = array_reverse(file("/tmp/entware_install.log"));
			else
				$d_complete[] = "Starting...";
			ControlFactory::add_multiline_label($defs, '', implode("",$d_complete), 10);
			if (preg_match("|Info: Next step packages installation|",file_get_contents ("/tmp/entware_install.log"))){
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog51');
				exec('/opt/bin/opkg update  >> /tmp/entware_install.log &');			
			}else
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog4');
			
			$attrs['timer'] = ActionFactory::timer(1000);
			$attrs['actions'] = array(GUI_EVENT_TIMER => ActionFactory::close_dialog_and_run($install_dialog));
			return  ActionFactory::show_dialog('%tr%t16',$defs,false, 1000,$attrs);
		}
		if ($user_input->control_id === 'install_dialog51'){
			$defs = array();
			$this->counter = $this->counter +1;
			$qtime = HD::sec_format_duration($this->counter);
			ControlFactory::add_label($defs, '', "%ext%<key_local>sec__1<p>$qtime</p></key_local>");
			$d_complete = array_reverse(file("/tmp/entware_install.log"));
			ControlFactory::add_multiline_label($defs, '', implode("",$d_complete), 10);
			if (preg_match("|Updated list of available|",file_get_contents ("/tmp/entware_install.log"))){
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog52');
				if ($this->platform=='ARMv7')
					exec('/opt/bin/opkg install entware-opt >> /tmp/entware_install.log &');
				else
					exec('/opt/bin/opkg install ldconfig findutils >> /tmp/entware_install.log &');
			}else
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog51');
			
			$attrs['timer'] = ActionFactory::timer(1000);
			$attrs['actions'] = array(GUI_EVENT_TIMER => ActionFactory::close_dialog_and_run($install_dialog));
			return  ActionFactory::show_dialog('%tr%t16',$defs,false, 1000,$attrs);
		}
		if ($user_input->control_id === 'install_dialog52'){
			$defs = array();
			$this->counter = $this->counter +1;
			$qtime = HD::sec_format_duration($this->counter);
			ControlFactory::add_label($defs, '', "%ext%<key_local>sec__1<p>$qtime</p></key_local>");
			$d_complete = array_reverse(file("/tmp/entware_install.log"));
			ControlFactory::add_multiline_label($defs, '', implode("",$d_complete), 10);
			if (preg_match("/Configuring entware-opt|Configuring findutils/",file_get_contents ("/tmp/entware_install.log"))){
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog5');
				if ($this->platform=='ARMv7'){
					if (!file_exists("/opt/usr/lib/locale/locale-archive"))
						exec('wget http://pkg.entware.net/binaries/other/locale-archive.2.23 -O /opt/usr/lib/locale/locale-archive >> /tmp/entware_install.log &');
					exec ('echo "Info: Create boot script" >> /tmp/entware_install.log');
				}else{
					exec('ldconfig > /dev/null 2>&1');
					exec('[ -f /etc/TZ ] && ln -sf /etc/TZ /opt/etc/TZ');
					exec ('echo "Info: Create boot script" >> /tmp/entware_install.log');
				}	
			}else
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog52');
			
			$attrs['timer'] = ActionFactory::timer(1000);
			$attrs['actions'] = array(GUI_EVENT_TIMER => ActionFactory::close_dialog_and_run($install_dialog));
			return  ActionFactory::show_dialog('%tr%t16',$defs,false, 1000,$attrs);
		}
		if ($user_input->control_id === 'install_dialog5'){
			$defs = array();
			$this->counter = $this->counter +1;
			$qtime = HD::sec_format_duration($this->counter);
			ControlFactory::add_label($defs, '', "%ext%<key_local>sec__1<p>$qtime</p></key_local>");
			$d_complete = array_reverse(file("/tmp/entware_install.log"));
			ControlFactory::add_multiline_label($defs, '', implode("",$d_complete), 10);
			if (preg_match("|Info: Create boot script|",file_get_contents ("/tmp/entware_install.log"))){
				if (!file_exists('/config/boot'))
					mkdir('/config/boot', 0777);
				if (($this->install_dir == true)&&($this->platform=='ARMv7')){
					file_put_contents("/config/boot/optboot.sh", "#! /bin/sh\nrm -rf /opt\nln -sf ".$this->install_dir."/Entware-ng /opt\nln -snf /opt/usr/lib/locale /usr/lib32/locale\necho \"[ -r /opt/etc/profile ] && . /opt/etc/profile\" >> /etc/profile");
					exec ('chmod +x /config/boot/optboot.sh');
					exec ('echo "Info: Created" >> /tmp/entware_install.log');
					$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog6');
				}else{
					file_put_contents("/config/boot/optboot.sh", "#! /bin/sh\nrm -rf /opt\nln -sf ".$this->install_dir."/Entware-ng /opt\necho \"[ -r /opt/etc/profile ] && . /opt/etc/profile\" >> /etc/profile");
					exec ('chmod +x /config/boot/optboot.sh');
					exec ('echo "Info: Created" >> /tmp/entware_install.log');
					$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog7');
				}
				
			}else
				$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog5');
			$attrs['timer'] = ActionFactory::timer(1000);
			$attrs['actions'] = array(GUI_EVENT_TIMER => ActionFactory::close_dialog_and_run($install_dialog));
			return  ActionFactory::show_dialog('%tr%t16',$defs,false, 1000, $attrs);
		}
		if ($user_input->control_id === 'install_dialog6'){
			$defs = array();
			$this->counter = $this->counter +1;
			$qtime = HD::sec_format_duration($this->counter);
			ControlFactory::add_label($defs, '', "%ext%<key_local>sec__1<p>$qtime</p></key_local>");
			$locale = 0;
			$locale_ops = array();
			$locale_ops[1] = 'ru_RU.UTF-8';
			$locale_ops[2] = 'en_US.UTF-8';
			ControlFactory::add_vgap($defs, 30);
			ControlFactory::add_combobox($defs, $this, null,
				'locale', '',
				$locale, $locale_ops, 0, $need_confirm = false, $need_apply = false
			);
			ControlFactory::add_vgap($defs, 30);
			$install_dialog = UserInputHandlerRegistry::create_action($this, 'install_dialog7');
			ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_install_dialog', '%tr%t6', 200, $install_dialog);
			return  ActionFactory::show_dialog('%tr%t15',$defs, false,1000,$attrs);
		}
		if ($user_input->control_id === 'install_dialog7'){
			$defs = array();
			$this->counter = $this->counter +1;
			$qtime = HD::sec_format_duration($this->counter);
			ControlFactory::add_label($defs, '', "%ext%<key_local>sec__1<p>$qtime</p></key_local>");
			if (($this->install_dir == true)&&($this->platform=='ARMv7')){
				$profile_edit = "/opt/etc/profile";
				$s = file_get_contents($profile_edit);
				if ((isset($user_input->locale))&&($user_input->locale == 1)){
					$s = str_replace(
					array ("#export LANG='ru_RU.UTF-8'","#export LC_ALL='ru_RU.UTF-8'","export LANG='en_US.UTF-8'","export LC_ALL='en_US.UTF-8'"),
					array ("export LANG='ru_RU.UTF-8'","export LC_ALL='ru_RU.UTF-8'","#export LANG='en_US.UTF-8'","#export LC_ALL='en_US.UTF-8'"),
					$s);
					file_put_contents($profile_edit, $s);
					$deluge_edit = DuneSystem::$properties['install_dir_path'].'/bin/start_deluge.sh';
					$s = file_get_contents($deluge_edit);
					$s = str_replace(
					array ("#export LANG='ru_RU.UTF-8'","#export LC_ALL='ru_RU.UTF-8'"),
					array ("export LANG='ru_RU.UTF-8'","export LC_ALL='ru_RU.UTF-8'"),
					$s);
					file_put_contents($deluge_edit, $s);
				}
				exec("/config/boot/optboot.sh");
			}
			$install_dialog = ActionFactory::reset_controls($this->do_get_control_defs($plugin_cookies));
			return ActionFactory::show_title_dialog('%tr%t13', $install_dialog, '%tr%t13', 1000, 1);
			
		}
        return ActionFactory::reset_controls(
            $this->do_get_control_defs($plugin_cookies));
    }
}

///////////////////////////////////////////////////////////////////////////
?>
