<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/default_dune_plugin.php';
require_once 'lib/utils.php';
require_once 'Smart_config.php';
require_once 'Smart_entry_handler.php';
require_once 'Smart_setup_screen.php';
///////////////////////////////////////////////////////////////////////////

class SmartPlugin extends DefaultDunePlugin
{
    public function __construct()
    {
        $this->entry_handler = new SmartEntryHandler();
		$this->add_screen(new SmartSetupScreen());
    }
}

///////////////////////////////////////////////////////////////////////////
?>
