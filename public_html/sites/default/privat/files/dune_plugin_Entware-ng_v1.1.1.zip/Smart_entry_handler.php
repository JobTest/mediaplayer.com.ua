﻿<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/user_input_handler_registry.php';
class SmartEntryHandler
    implements UserInputHandler
{

    public function __construct()
    {
        UserInputHandlerRegistry::get_instance()->
            register_handler($this);
    }

    public function get_handler_id()
    {
        return 'entry';
    }
	
    public function handle_user_input(&$user_input, &$plugin_cookies)
    {
		$attrs['dialog_params'] = array('frame_style' => DIALOG_FRAME_STYLE_GLASS);
		
		if ((isset($user_input->control_id))&&($user_input->control_id == 'save_yes'))
        {
			$plugin_cookies->disclaimer = 'yes';
			return ActionFactory::open_folder();
		}
		else if ($user_input->handler_id == 'entry')
        {
			$defs = array();
			$disclaimer = isset($plugin_cookies->disclaimer) ? $plugin_cookies->disclaimer : 'no';
			if (file_exists('/ltu')){
				ControlFactory::add_multiline_label($defs, '', '%tr%t58',8);
				ControlFactory::add_close_dialog_button($defs, '%tr%t57', 300);
				return  ActionFactory::show_dialog('%tr%t54',$defs, true,1000,$attrs);
			}
			if ($disclaimer == 'yes')
				return ActionFactory::open_folder();
			else{
				$defs = array();
				ControlFactory::add_multiline_label($defs, '', '%tr%t55',8);
				$do = UserInputHandlerRegistry::create_action($this, 'save_yes');
				ControlFactory::add_custom_close_dialog_and_apply_buffon($defs,'_do', '%tr%t56', 550, $do);
				ControlFactory::add_close_dialog_button($defs, '%tr%t57', 550);
				return  ActionFactory::show_dialog('%tr%t54',$defs, true,1000,$attrs);
			}
		}	
    }
}

///////////////////////////////////////////////////////////////////////////
?>
